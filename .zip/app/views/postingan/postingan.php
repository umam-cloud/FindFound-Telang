<?php 
    $filterKategori = $data['filters']['kategori'];
    $filterStatus = $data['filters']['status'];
    $filterWaktu = $data['filters']['waktu'];
?>

<main class="max-w-7xl mx-auto px-6 py-10 md:py-14">
    <div class="flex flex-col md:flex-row md:items-end justify-between mb-8">
        <div>
            <h1 class="text-3xl md:text-4xl font-extrabold text-gray-900 tracking-tight mb-2">Temukan barang yang hilang.</h1>
            <p class="text-sm text-gray-500 font-medium"><?=$data['total_data']?> Hasil ditemukan</p>
        </div>
        <div class="mt-4 md:mt-0 flex items-center gap-2 bg-gray-50/50 px-4 py-2 rounded-full border border-gray-100">
            <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400">Urutan:</span>
            <select 
                onchange="location = this.value;" 
                class="bg-transparent border-none text-[#006D77] font-bold text-sm focus:ring-0 outline-none cursor-pointer appearance-none pr-4 relative">
                
                <option value="terbaru" <?= (!isset($data['urutan']) || $data['urutan'] == 'terbaru') ? 'selected' : '' ?>>Terbaru</option>
                <option value="terlama" <?= (isset($data['urutan']) && $data['urutan'] == 'terlama') ? 'selected' : '' ?>>Terlama</option>
            </select>
            <svg class="w-3 h-3 text-[#006D77] -ml-4 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
        </div>
    </div>

    <div class="relative w-full mb-12">
        <span class="absolute inset-y-0 left-6 flex items-center text-gray-400">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
        </span>
        <input value="<?= isset($data['keyword']) ? $data['keyword'] : ''?>" type="text" id="search" placeholder="Cari barang yang hilang atau ditemukan..." class="w-full bg-white border border-gray-100 shadow-sm rounded-full py-4 pl-14 pr-6 focus:outline-none focus:ring-2 focus:ring-[#006D77] text-sm text-gray-700 transition-all">
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-10">
        <form action="<?=BASEURL?>/postingan/" method="POST">
            <aside class="lg:col-span-1 flex flex-col gap-8">
                <div>
                    <h3 class="text-[10px] font-bold tracking-[0.2em] uppercase text-gray-500 mb-4 flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
                        Kategori
                    </h3>
                    <div class="flex flex-col gap-3">
                        <?php foreach($data['kategori'] as $kategori):?>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="checkbox" class="w-4 h-4 rounded-sm border-gray-300 text-[#006D77] focus:ring-[#006D77]" name="kategori[]" value="<?=$kategori['id']?>" <?= in_array($kategori['id'], $filterKategori) ? 'checked' : ''; ?>>
                                <span class="text-sm text-gray-600 group-hover:text-gray-900 transition-colors"><?=$kategori['nama_kategori']?></span>
                            </label>
                        <?php endforeach ?>
                    </div>
                </div>
    
               <div>
                    <h3 class="text-[10px] font-bold tracking-[0.2em] uppercase text-gray-500 mb-4 flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        Status
                    </h3>
                    <div class="flex bg-gray-100 rounded-full p-1 border border-gray-200/50">
                        <div class="flex-1">
                            <input type="radio" name="status" value="semua" id="status-semua" class="hidden peer" <?= ($filterStatus == 'semua') ? 'checked' : ''; ?>>
                            <label for="status-semua" class="block w-full text-center py-2 rounded-full text-[10px] font-bold tracking-wide text-gray-500 cursor-pointer transition-all peer-checked:bg-[#006D77] peer-checked:text-white peer-checked:shadow-sm">
                                Semua
                            </label>
                        </div>
    
                        <div class="flex-1">
                            <input type="radio" name="status" value="hilang" id="status-hilang" class="hidden peer" <?= ($filterStatus == 'hilang') ? 'checked' : ''; ?>>
                            <label for="status-hilang" class="block w-full text-center py-2 rounded-full text-[10px] font-bold tracking-wide text-gray-500 cursor-pointer transition-all peer-checked:bg-[#006D77] peer-checked:text-white peer-checked:shadow-sm">
                                Hilang
                            </label>
                        </div>
    
                        <div class="flex-1">
                            <input type="radio" name="status" value="temuan" id="status-ditemukan" class="hidden peer" <?= ($filterStatus == 'temuan') ? 'checked' : ''; ?>>
                            <label for="status-ditemukan" class="block w-full text-center py-2 rounded-full text-[10px] font-bold tracking-wide text-gray-500 cursor-pointer transition-all peer-checked:bg-[#006D77] peer-checked:text-white peer-checked:shadow-sm">
                                Ditemukan
                            </label>
                        </div>
                    </div>
                </div>
    
                <div>
                    <h3 class="text-[10px] font-bold tracking-[0.2em] uppercase text-gray-500 mb-4 flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        Rentang Waktu
                    </h3>
                    <div class="relative">
                        <select class="w-full bg-gray-100 border-none text-gray-700 text-xs font-bold py-3.5 px-4 rounded-xl focus:ring-2 focus:ring-[#006D77] outline-none appearance-none cursor-pointer" name="waktu">
                            <option value="all" <?= ($filterWaktu == 'all') ? 'selected' : ''; ?>>Semua Waktu</option>
                            <option value="7" <?= ($filterWaktu == '7') ? 'selected' : ''; ?>>7 Hari Terakhir</option>
                            <option value="30"<?= ($filterWaktu == '30') ? 'selected' : ''; ?>>30 Hari Terakhir</option>
                        </select>
                        <span class="absolute inset-y-0 right-4 flex items-center pointer-events-none text-gray-500">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                        </span>
                    </div>
                </div>
    
                <button class="w-full bg-[#006D77] hover:bg-[#005a63] text-white py-3.5 rounded-full text-sm font-bold shadow-md transition-all active:scale-[0.98] mt-2" type="submit">
                    Terapkan Filter
                </button>
            </aside>
        </form>

        <div class="lg:col-span-3">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php if (empty($data['postingan'])): ?>
                    <div class="col-span-full flex flex-col items-center justify-center bg-gray-50 border border-gray-100 rounded-[1.5rem] p-12 text-center min-h-[300px]">
                        <div class="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-6 shadow-sm border border-gray-100">
                            <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900 mb-2">Tidak Ada Postingan</h3>
                        <p class="text-sm text-gray-500 max-w-md mx-auto leading-relaxed">Tidak ada postingan yang sesuai dengan filter atau pencarian Anda. Coba gunakan kata kunci yang berbeda atau sesuaikan filter Anda.</p>
                    </div>
                <?php else: ?>
                <?php foreach ($data['postingan'] as $post):
                    $tanggal = isset($post['created_at']) ? date('d - m - Y', strtotime($post['created_at'])) : 'Tanggal tidak diketahui';
                    $jenis = $post['jenis_laporan'];

                    if ($jenis == 'hilang') {
                        $badgeClass = 'bg-red-100 text-red-800';
                    }else{
                        $badgeClass = 'bg-[#D1E9E6] text-[#006D77]';
                    }?>
                    <a href="<?=BASEURL?>/postingan/detailPostingan/<?=$post['kode_postingan']?>" class="bg-white rounded-[1.5rem] overflow-hidden shadow-sm border border-gray-100 flex flex-col group hover:shadow-md transition-all cursor-grab" >
                        <div class="relative h-44 bg-gray-200 overflow-hidden">
                            <span class="<?=$badgeClass?> absolute top-4 left-4 z-10 text-[9px] font-bold px-2.5 py-1 rounded-sm uppercase tracking-widest shadow-sm"><?=$post['jenis_laporan']?></span>
                            <img src="<?=BASEURL?>/img/postingan/<?=$post['file_path']?>" alt="Dompet" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                        </div>
                        <div class="p-6 flex-grow flex flex-col">
                            <div class="flex justify-between items-start mb-2">
                                <h3 class="text-base font-bold text-gray-900 pr-4 leading-tight"><?=$post['judul']?></h3>
                                <button class="text-gray-400 hover:text-[#006D77] transition-colors"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"></path></svg></button>
                            </div>
                            <p class="text-xs text-gray-500 mb-6 flex-grow leading-relaxed line-clamp-3"><?=$post['deskripsi']?></p>
                            <div class="flex items-center justify-between text-[10px] text-gray-400 font-medium pt-4 border-t border-gray-50">
                                <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path></svg> <?=$post['lokasi_spesifik']?></span>
                                <span class="flex items-center gap-1"><svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg><?=$tanggal?></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; endif; ?>

            </div>
            <div class="flex justify-center items-center gap-2 mt-16 mb-12">
                <?php if ($data['halaman_aktif'] > 1 ):?>
                    <a href="?halaman=<?= $data['halaman_aktif'] - 1 ?><?= isset($data['urutan']) ? '&urutan='.$data['urutan'] : ''?><?= isset($data['keyword']) ? '&search='.$data['keyword'] : ''?>" class="w-8 h-8 rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 flex items-center justify-center transition-colors">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                    </a>
                <?php endif ?>

                <?php for ($i = 1; $i <= $data['total_halaman']; $i++) : ?>
                    <a href="?halaman=<?= $i ?><?= isset($data['urutan']) ? '&urutan='.$data['urutan'] : ''?><?= isset($data['keyword']) ? '&search='.$data['keyword'] : ''?>" 
                    class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all 
                    <?= ($i == $data['halaman_aktif']) ? 'bg-[#006D77] text-white shadow-md' : 'bg-transparent text-gray-600 hover:bg-gray-100' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <?php if ($data['halaman_aktif'] < $data['total_halaman']) : ?>
                    <a href="?halaman=<?= $data['halaman_aktif'] + 1?><?= isset($data['urutan']) ? '&urutan='.$data['urutan'] : ''?><?= isset($data['keyword']) ? '&search='.$data['keyword'] : ''?>" class="w-8 h-8 rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 flex items-center justify-center transition-colors">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                    </a>
                <?php endif; ?>
            </div>

            <div class="md:col-span-2 bg-[#006D77] rounded-[1.5rem] p-8 md:p-10 text-white flex flex-col justify-center relative overflow-hidden shadow-lg mt-2">
                <div class="absolute right-0 bottom-0 opacity-20 w-1/2 h-full pointer-events-none mix-blend-overlay">
                    <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=400" alt="Map pattern" class="w-full h-full object-cover">
                </div>
                
                <div class="relative z-10 max-w-sm">
                    <p class="text-[10px] font-bold uppercase tracking-widest text-teal-200 mb-3">Informasi Komunitas</p>
                    <h2 class="text-2xl font-bold mb-4 leading-tight">Bantu tingkatkan keamanan di area Anda.</h2>
                    <p class="text-sm text-teal-50 opacity-90 leading-relaxed mb-8">
                        Aktifkan notifikasi untuk mendapatkan pemberitahuan instan saat ada barang yang hilang atau ditemukan di radius 5km dari posisi Anda.
                    </p>
                    <button class="bg-white text-[#006D77] px-6 py-3 rounded-full text-xs font-bold shadow-md hover:bg-gray-50 transition-colors w-max">
                        Aktifkan Sekarang
                    </button>
                </div>
            </div>

        </div>
    </div>

</main>

<script>
    const selectSort = document.querySelector('select');
    const search = document.getElementById('search');
    
    selectSort.addEventListener('change', function() {
        const url = new URL(window.location.href);
        url.searchParams.set('urutan', this.value);
        window.location.href = url.href;
    });


    search.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            const url = new URL(window.location.href);
            url.searchParams.set('search', this.value);
            window.location.href = url.href;
        }
    });
</script>